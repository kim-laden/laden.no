(() => {
  const API = '/labs/api';
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const QUOTES = [
    'Scope is a love language. Written permission first — then curiosity.',
    'Encoding is not encryption. Base64 is a costume, not a vault.',
    'A quiet finding with a clear PoC beats a loud CVSS flex.',
    'robots.txt is a treasure map, not a lock. Still: stay in scope.',
    'alg=none is a nightmare you only need to meet once.',
    'Report like a pro: summary, steps, impact, fix. Signal over noise.',
    'The best exploit is the one you never run out of scope.',
    'HttpOnly + Secure are small flags with large consequences.',
  ];
  const FACTS = [
    'JWT stands for JSON Web Token — three Base64url chunks: header.payload.signature.',
    'ROT13 is its own inverse: apply it twice and you’re back.',
    'SHA-256 digests are always 64 hex characters.',
    'IDOR = changing an id and seeing someone else’s data without an authz check.',
    'Open redirects often fuel phishing chains and OAuth token theft.',
    'SSRF hunters always think about link-local metadata (169.254.169.254).',
    'CSP with unsafe-inline is basically a polite suggestion.',
    'The Laden motto behind Scope First is three words: hunt ethically always.',
  ];
  let factIdx = Math.floor(Math.random() * FACTS.length);

  function token() { return localStorage.getItem('laden_v12_token') || ''; }
  function show(logged) {
    const gate = $('#acct-gate');
    const info = $('#acct-info');
    if (gate) gate.classList.toggle('hidden', logged);
    if (info) info.classList.toggle('hidden', !logged);
  }
  function setFact() {
    const el = $('#fact-text');
    if (el) el.textContent = FACTS[factIdx % FACTS.length];
  }

  function renderAccountLabcard(u) {
    const el = $('#acct-labcard-card');
    if (!el || !window.LabCard || !window.LabCard.renderInto) return;
    const p = u || (window.LabCard.getProfile && window.LabCard.getProfile()) || {};
    const username = p.username || 'hunter';
    const labId = p.lab_id || (p.id != null ? '969-' + String(p.id).padStart(3, '0') : '969-???');
    const balance = (window.LLT && typeof window.LLT.balance === 'function')
      ? window.LLT.balance() : (p.llt != null ? p.llt : 0);
    const currentXp = (window.LLT && window.LLT.get && window.LLT.get().xp != null)
      ? window.LLT.get().xp : (p.xp != null ? p.xp : 0);
    window.LabCard.renderInto(el, {
      member: true,
      name: p.display_name || username,
      nick: username,
      lab_id: labId,
      title: p.title || '',
      title_label: p.title_label || '',
      llt: balance,
      xp: currentXp,
      role: p.role || 'member',
      skin: p.labcard_skin || 'default',
      avatar_id: p.avatar_id || p.avatar || '',
      avatar: p.avatar_id || p.avatar || '',
    });
  }
  function setQuote() {
    const el = $('#daily-quote');
    if (!el) return;
    const day = Math.floor(Date.now() / 86400000);
    el.textContent = '“' + QUOTES[day % QUOTES.length] + '”';
  }
  function setOk(msg) {
    const el = $('#acct-ok');
    if (el) el.textContent = msg || '';
  }
  function setTab(tab) {
    const forms = {
      login: $('#acct-login'),
      register: $('#acct-register'),
      forgot: $('#acct-forgot'),
      reset: $('#acct-reset'),
    };
    Object.keys(forms).forEach(k => {
      if (forms[k]) forms[k].classList.toggle('hidden', k !== tab);
    });
    $$('#acct-tabs button').forEach(b => {
      const on = (tab === 'reset') ? false : (b.dataset.acctTab === tab);
      b.classList.toggle('active', on);
    });
  }

  async function loadTracks() {
    const box = $('#track-chips');
    if (!box) return;
    try {
      const res = await fetch(API + '/challenges', {
        headers: token() ? { Authorization: 'Bearer ' + token() } : {}
      });
      const data = await res.json();
      const list = data.challenges || [];
      const tracks = {};
      list.forEach(c => { tracks[c.track] = (tracks[c.track] || 0) + 1; });
      box.innerHTML = Object.keys(tracks).sort().map(t =>
        `<span class="tag">${t} · ${tracks[t]}</span>`
      ).join('');
    } catch {
      box.innerHTML = '<span class="muted">Tracks load after login.</span>';
    }
  }

  async function loadMe() {
    const tok = token();
    if (!tok) { show(false); return; }
    try {
      const res = await fetch(API + '/me', { headers: { Authorization: 'Bearer ' + tok } });
      const data = await res.json();
      if (!res.ok) throw new Error('auth');
      const u = data.user || data;
      show(true);
      renderAccountLabcard(u);
      const user = u.username || 'hunter';
      $('#info-user').textContent = user;
      $('#info-xp').textContent = u.xp ?? 0;
      const solved = u.solved ?? 0;
      const total = u.total_challenges ?? 24;
      $('#info-solved').textContent = solved;
      $('#info-total').textContent = total;
      $('#info-role').textContent = u.role || 'member';
      const em = $('#info-email');
      if (em) em.textContent = u.email || '—';
      $('#info-display').textContent =
        (u.display_name ? u.display_name + ' · ' : '') +
        'Dashboard for ethical operators. Flags stay laden{…}.';
      $('#acct-title').textContent = 'Welcome, ' + (u.display_name || user);
      const pct = total ? Math.min(100, Math.round((solved / total) * 100)) : 0;
      const bar = $('#info-progress');
      if (bar) bar.style.width = pct + '%';
      const lab = $('#info-progress-label');
      if (lab) lab.textContent = solved + ' / ' + total + ' · ' + pct + '%';
      document.querySelectorAll('#nav-account,#nav-account-btn').forEach(el => { el.textContent = user; });
      const lltVal = (u.llt != null ? u.llt : '—');
      const xpVal = (u.xp != null ? u.xp : 0);
      const lltEl = $('#info-llt');
      if (lltEl) lltEl.textContent = lltVal;
      const lltCard = $('#info-llt-card');
      if (lltCard) lltCard.textContent = lltVal;
      const xpCard = $('#info-xp-card');
      if (xpCard) xpCard.textContent = xpVal;
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      initLabcardPicker(u);
      initAvatarPicker(u);
      initTitleShop(u);
      await loadTracks();
    } catch {
      localStorage.removeItem('laden_v12_token');
      show(false);
    }
  }

  $$('#acct-tabs button').forEach(b => {
    b.onclick = () => {
      setOk('');
      setTab(b.dataset.acctTab);
    };
  });

  const form = $('#acct-login');
  if (form) form.onsubmit = async (e) => {
    e.preventDefault();
    $('#acct-err').textContent = '';
    setOk('');
    const fd = new FormData(e.target);
    try {
      const res = await fetch(API + '/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: fd.get('username'), password: fd.get('password') })
      });
      const data = await res.json();
      if (!res.ok) throw new Error((data && data.error) || 'fail');
      localStorage.setItem('laden_v12_token', data.token);
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      await loadMe();
    } catch {
      $('#acct-err').textContent = 'Login failed — check username/email and password.';
    }
  };

  const reg = $('#acct-register');
  if (reg) reg.onsubmit = async (e) => {
    e.preventDefault();
    $('#acct-reg-err').textContent = '';
    setOk('');
    const fd = new FormData(e.target);
    try {
      const res = await fetch(API + '/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: fd.get('username'),
          email: fd.get('email'),
          password: fd.get('password'),
          display_name: fd.get('display_name') || undefined,
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error((data && data.error) || 'fail');
      localStorage.setItem('laden_v12_token', data.token);
      setOk('Account created. Welcome mail queued.');
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      await loadMe();
    } catch (err) {
      $('#acct-reg-err').textContent = err.message === 'username_or_email_taken'
        ? 'Username or email already taken.'
        : err.message === 'invalid_email'
          ? 'Enter a valid email.'
          : 'Could not create account.';
    }
  };

  const forgot = $('#acct-forgot');
  if (forgot) forgot.onsubmit = async (e) => {
    e.preventDefault();
    $('#acct-forgot-err').textContent = '';
    setOk('');
    const fd = new FormData(e.target);
    try {
      const res = await fetch(API + '/auth/forgot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: fd.get('email') })
      });
      const data = await res.json();
      if (!res.ok) throw new Error('fail');
      setOk(data.message || 'If that email is registered, a reset link has been sent.');
      e.target.reset();
    } catch {
      $('#acct-forgot-err').textContent = 'Request failed — try again.';
    }
  };

  const reset = $('#acct-reset');
  if (reset) reset.onsubmit = async (e) => {
    e.preventDefault();
    $('#acct-reset-err').textContent = '';
    setOk('');
    const fd = new FormData(e.target);
    try {
      const res = await fetch(API + '/auth/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: fd.get('token'), password: fd.get('password') })
      });
      const data = await res.json();
      if (!res.ok) throw new Error((data && data.error) || 'fail');
      if (data.token) localStorage.setItem('laden_v12_token', data.token);
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      setOk('Password updated. You are signed in.');
      // clear reset query
      try {
        const u = new URL(location.href);
        u.searchParams.delete('reset');
        history.replaceState({}, '', u.pathname + u.search + u.hash);
      } catch {}
      await loadMe();
    } catch (err) {
      $('#acct-reset-err').textContent = err.message === 'invalid_or_expired_token'
        ? 'Reset link invalid or expired.'
        : 'Could not reset password.';
    }
  };

  const logout = $('#acct-logout');
  if (logout) logout.onclick = () => {
    localStorage.removeItem('laden_v12_token');
    try { if (window.LabCard && window.LabCard.clearCache) window.LabCard.clearCache(); } catch {}
    show(false);
    setTab('login');
    document.querySelectorAll('#nav-account,#nav-account-btn').forEach(el => { el.textContent = 'Login'; });
  };

  const next = $('#fact-next');
  if (next) next.onclick = () => { factIdx++; setFact(); };

  // ?reset=TOKEN → show reset form
  let resetToken = '';
  try {
    resetToken = new URL(location.href).searchParams.get('reset') || '';
  } catch {}
  if (resetToken) {
    const tokInput = $('#acct-reset-token');
    if (tokInput) tokInput.value = resetToken;
    setTab('reset');
    setOk('Enter a new password to finish the reset.');
  } else {
    setTab('login');
  }


  // --- Lab card skin picker ---
  let selectedSkin = 'default';
  let appliedSkin = 'default';

  function skinMeta() {
    if (window.LabCard && window.LabCard.SKIN_META) return window.LabCard.SKIN_META;
    return {};
  }
  function skinList() {
    if (window.LabCard && window.LabCard.SKINS) return window.LabCard.SKINS.slice();
    return ['default','neon-grid','purple-haze','ice-ops','ember','matrix','gold-op','void'];
  }
  function setSkinMsg(msg, isErr) {
    const el = $('#labcard-skin-msg');
    if (!el) return;
    el.textContent = msg || '';
    el.style.color = isErr ? '#ff6b7a' : 'rgba(230,241,255,.65)';
  }
  function paintSkinGrid() {
    const grid = $('#labcard-skin-grid');
    if (!grid) return;
    if (window.LabCard && window.LabCard.injectCss) window.LabCard.injectCss();
    const meta = skinMeta();
    grid.innerHTML = skinList().map(id => {
      const m = meta[id] || { label: id, blurb: id };
      const sel = id === selectedSkin ? ' is-selected' : '';
      return `<button type="button" class="labcard-skin-opt${sel}" data-skin="${id}" role="option" aria-selected="${id===selectedSkin}">
        <div class="labcard-skin-preview pv-${id}" aria-hidden="true"></div>
        <strong>${m.label || id}</strong>
        <span>${m.blurb || ''}${id===appliedSkin ? ' · active' : ''}</span>
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-skin]').forEach(btn => {
      btn.onclick = () => {
        selectedSkin = btn.getAttribute('data-skin');
        paintSkinGrid();
        setSkinMsg(selectedSkin === appliedSkin
          ? 'Already active — apply is free.'
          : 'Ready to apply · costs 10 LLT.');
      };
    });
    const cur = $('#labcard-current-skin');
    if (cur) cur.textContent = appliedSkin;
  }

  async function applyLabcardSkin() {
    const tok = token();
    if (!tok) { setSkinMsg('Sign in to customize.', true); return; }
    const skin = selectedSkin;
    setSkinMsg('Applying…');
    const btn = $('#labcard-apply');
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(API + '/llt/labcard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok },
        body: JSON.stringify({ skin }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) { setSkinMsg('Session expired — sign in again.', true); return; }
      if (!res.ok || data.ok === false) {
        const err = data.error || 'failed';
        setSkinMsg(err === 'insufficient_llt'
          ? 'Not enough LLT (need 10). Earn more on challenges.'
          : err === 'invalid_skin' ? 'Invalid skin.' : ('Could not apply: ' + err), true);
        if (data.balance != null) {
          document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        }
        return;
      }
      appliedSkin = data.skin || skin;
      selectedSkin = appliedSkin;
      if (data.balance != null) {
        document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        const lltEl = $('#info-llt'); if (lltEl) lltEl.textContent = data.balance;
        const lltCard = $('#info-llt-card'); if (lltCard) lltCard.textContent = data.balance;
      }
      try {
        if (window.LabCard) {
          window.LabCard.clearCache();
          window.LabCard.setLocalSkin(appliedSkin);
          await window.LabCard.refresh(true);
        }
      } catch {}
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      paintSkinGrid();
      const charged = data.charged != null ? data.charged : 0;
      setSkinMsg(charged
        ? 'Skin applied · −' + charged + ' LLT. Hover your nav name to see it.'
        : 'Skin already active · no charge.');
    } catch {
      setSkinMsg('Network error — try again.', true);
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function initLabcardPicker(u) {
    const skin = (u && u.labcard_skin) || (window.LabCard && window.LabCard.getSkin && window.LabCard.getSkin()) || 'default';
    appliedSkin = skin;
    selectedSkin = skin;
    paintSkinGrid();
    const apply = $('#labcard-apply');
    if (apply && !apply._wired) {
      apply._wired = true;
      apply.onclick = () => applyLabcardSkin();
    }
  }



  // --- Member avatar picker (100 LLT) ---
  let selectedAvatar = '';
  let appliedAvatar = '';

  function avatarList() {
    if (window.LadenAvatars && window.LadenAvatars.list) return window.LadenAvatars.list();
    return [];
  }
  function setAvatarMsg(msg, isErr) {
    const el = $('#avatar-msg');
    if (!el) return;
    el.textContent = msg || '';
    el.style.color = isErr ? '#ff6b7a' : 'rgba(230,241,255,.65)';
  }
  function paintAvatarGrid() {
    const grid = $('#avatar-grid');
    if (!grid) return;
    try { if (window.LadenAvatars && window.LadenAvatars.ensureCss) window.LadenAvatars.ensureCss(); } catch {}
    const list = avatarList();
    if (!list.length) {
      grid.innerHTML = '<p class="muted">Avatars loading…</p>';
      return;
    }
    grid.innerHTML = list.map(m => {
      const id = m.id;
      const sel = id === selectedAvatar ? ' is-selected' : '';
      const html = (window.LadenAvatars && window.LadenAvatars.html) ? window.LadenAvatars.html(id) : '';
      return `<button type="button" class="laden-av-opt${sel}" data-avatar="${id}" role="option" aria-selected="${id===selectedAvatar}">
        ${html}
        <strong>${m.name || id}</strong>
        <span>${id}${id===appliedAvatar ? ' · active' : ''}</span>
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-avatar]').forEach(btn => {
      btn.onclick = () => {
        selectedAvatar = btn.getAttribute('data-avatar') || '';
        paintAvatarGrid();
        setAvatarMsg(selectedAvatar === appliedAvatar
          ? 'Already active — apply is free.'
          : 'Ready to apply · costs 100 LLT.');
      };
    });
    const cur = $('#avatar-current');
    if (cur) cur.textContent = appliedAvatar || 'initials';
  }

  async function applyAvatar(forceId) {
    const tok = token();
    if (!tok) { setAvatarMsg('Sign in to customize.', true); return; }
    const avatar = forceId !== undefined ? forceId : selectedAvatar;
    if (!avatar) { setAvatarMsg('Pick an avatar first.', true); return; }
    setAvatarMsg('Applying…');
    const btn = $('#avatar-apply');
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(API + '/llt/avatar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok },
        body: JSON.stringify({ avatar }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) { setAvatarMsg('Session expired — sign in again.', true); return; }
      if (!res.ok || data.ok === false) {
        const err = data.error || 'failed';
        setAvatarMsg(err === 'insufficient_llt'
          ? 'Not enough LLT (need 100). Earn more on challenges.'
          : err === 'invalid_avatar' ? 'Invalid avatar.' : ('Could not apply: ' + err), true);
        if (data.balance != null) {
          document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        }
        return;
      }
      appliedAvatar = data.avatar_id || data.avatar || avatar;
      selectedAvatar = appliedAvatar;
      if (data.balance != null) {
        document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        const lltEl = $('#info-llt'); if (lltEl) lltEl.textContent = data.balance;
        const lltCard = $('#info-llt-card'); if (lltCard) lltCard.textContent = data.balance;
      }
      try {
        if (window.LabCard) {
          window.LabCard.clearCache();
          if (window.LabCard.setLocalAvatar) window.LabCard.setLocalAvatar(appliedAvatar);
          await window.LabCard.refresh(true);
        }
      } catch {}
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      paintAvatarGrid();
      const charged = data.charged != null ? data.charged : 0;
      setAvatarMsg(charged
        ? 'Avatar applied · −' + charged + ' LLT. Hover your nav name — open Caleb for the scared look.'
        : 'Avatar already active · no charge.');
    } catch {
      setAvatarMsg('Network error — try again.', true);
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function initAvatarPicker(u) {
    const id = (u && (u.avatar_id || u.avatar)) || (window.LabCard && window.LabCard.getAvatar && window.LabCard.getAvatar()) || '';
    appliedAvatar = id;
    selectedAvatar = id || (avatarList()[0] && avatarList()[0].id) || '';
    paintAvatarGrid();
    const apply = $('#avatar-apply');
    if (apply && !apply._wired) {
      apply._wired = true;
      apply.onclick = () => applyAvatar();
    }
    const clear = $('#avatar-clear');
    if (clear && !clear._wired) {
      clear._wired = true;
      clear.onclick = () => {
        setAvatarMsg('Initials are free for guests; members keep their last paid avatar until they pick another. Pick any character above to change (100 LLT).');
      };
    }
  }



  // --- Titles shop ---
  let titleCatalog = [];
  let titleOwned = [];
  let titleEquipped = '';
  let titleSelected = '';

  function setTitleMsg(msg, isErr) {
    const el = $('#title-shop-msg');
    if (!el) return;
    el.textContent = msg || '';
    el.style.color = isErr ? '#ff6b7a' : 'rgba(230,241,255,.65)';
  }

  function paintTitleGrid() {
    const grid = $('#title-shop-grid');
    if (!grid) return;
    if (!titleCatalog.length) {
      grid.innerHTML = '<p class="muted">Loading titles…</p>';
      return;
    }
    grid.innerHTML = titleCatalog.map(item => {
      const id = item.id;
      const owned = titleOwned.indexOf(id) >= 0;
      const eq = id === titleEquipped;
      const sel = id === titleSelected ? ' is-selected' : '';
      const cls = 'title-shop-opt' + (owned ? ' is-owned' : '') + (eq ? ' is-equipped' : '') + sel;
      const badge = eq ? '<span class="title-badge">equipped</span>' : (owned ? '<span class="title-badge">owned</span>' : '');
      const price = owned ? 'Owned · equip free' : (item.price + ' LLT');
      return `<button type="button" class="${cls}" data-title="${id}" role="option" aria-selected="${id===titleSelected}">
        <strong>${item.label || id}</strong>
        <span class="title-blurb">${item.blurb || ''}</span>
        <span class="title-price">${price}</span> ${badge}
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-title]').forEach(btn => {
      btn.onclick = () => {
        titleSelected = btn.getAttribute('data-title') || '';
        paintTitleGrid();
        const owned = titleOwned.indexOf(titleSelected) >= 0;
        const meta = titleCatalog.find(x => x.id === titleSelected);
        setTitleMsg(owned
          ? (titleSelected === titleEquipped ? 'Already equipped.' : 'Owned — click Equip.')
          : ('Buy for ' + ((meta && meta.price) || '?') + ' LLT, then Equip.'));
      };
    });
    const cur = $('#title-current');
    if (cur) {
      const meta = titleCatalog.find(x => x.id === titleEquipped);
      cur.textContent = meta ? meta.label : (titleEquipped || 'none');
    }
  }

  async function loadTitleCatalog(u) {
    try {
      const res = await fetch(API + '/llt/titles', {
        headers: token() ? { Authorization: 'Bearer ' + token() } : {},
      });
      const data = await res.json().catch(() => ({}));
      titleCatalog = data.catalog || [];
      titleOwned = data.owned || (u && u.titles) || [];
      titleEquipped = data.title || (u && u.title) || '';
      if (!titleSelected) titleSelected = titleEquipped || (titleCatalog[0] && titleCatalog[0].id) || '';
    } catch {
      titleCatalog = [];
    }
  }

  async function buyTitle() {
    const tok = token();
    if (!tok) { setTitleMsg('Sign in first.', true); return; }
    if (!titleSelected) { setTitleMsg('Pick a title.', true); return; }
    setTitleMsg('Buying…');
    const btn = $('#title-buy');
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(API + '/llt/title/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok },
        body: JSON.stringify({ title: titleSelected }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) { setTitleMsg('Session expired.', true); return; }
      if (!res.ok || data.ok === false) {
        setTitleMsg(data.error === 'insufficient_llt'
          ? 'Not enough LLT.'
          : ('Could not buy: ' + (data.error || 'failed')), true);
        if (data.balance != null) {
          document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        }
        return;
      }
      titleOwned = data.titles || titleOwned;
      if (data.balance != null) {
        document.querySelectorAll('[data-llt-balance]').forEach(el => { el.textContent = String(data.balance); });
        const lltEl = $('#info-llt'); if (lltEl) lltEl.textContent = data.balance;
        const lltCard = $('#info-llt-card'); if (lltCard) lltCard.textContent = data.balance;
      }
      try { if (window.LLT && window.LLT.sync) await window.LLT.sync(); } catch {}
      paintTitleGrid();
      const charged = data.charged != null ? data.charged : 0;
      setTitleMsg(charged
        ? 'Purchased · −' + charged + ' LLT. Now Equip it.'
        : (data.already_owned ? 'Already owned — Equip free.' : 'Owned.'));
    } catch {
      setTitleMsg('Network error.', true);
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  async function equipTitle(forceId) {
    const tok = token();
    if (!tok) { setTitleMsg('Sign in first.', true); return; }
    const tid = forceId !== undefined ? forceId : titleSelected;
    if (tid === undefined || tid === null) { setTitleMsg('Pick a title.', true); return; }
    if (tid && titleOwned.indexOf(tid) < 0) { setTitleMsg('Buy it first.', true); return; }
    setTitleMsg('Equipping…');
    const btn = $('#title-equip');
    if (btn) btn.disabled = true;
    try {
      const res = await fetch(API + '/llt/title/equip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok },
        body: JSON.stringify({ title: tid }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) { setTitleMsg('Session expired.', true); return; }
      if (!res.ok || data.ok === false) {
        setTitleMsg('Could not equip: ' + (data.error || 'failed'), true);
        return;
      }
      titleEquipped = data.title || '';
      titleOwned = data.titles || titleOwned;
      try {
        if (window.LabCard) {
          window.LabCard.clearCache();
          if (window.LabCard.setLocalTitle) window.LabCard.setLocalTitle(titleEquipped, data.title_label || '');
          await window.LabCard.refresh(true);
        }
      } catch {}
      paintTitleGrid();
      setTitleMsg(titleEquipped
        ? ('Equipped · ' + (data.title_label || titleEquipped))
        : 'Title cleared — role shows again.');
    } catch {
      setTitleMsg('Network error.', true);
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  function initTitleShop(u) {
    const lab = $('#title-lab-id');
    if (lab) lab.textContent = (u && u.lab_id) || (u && u.id != null ? ('969-' + String(u.id).padStart(3,'0')) : '—');
    loadTitleCatalog(u).then(() => {
      paintTitleGrid();
    });
    const buy = $('#title-buy');
    if (buy && !buy._wired) { buy._wired = true; buy.onclick = () => buyTitle(); }
    const eq = $('#title-equip');
    if (eq && !eq._wired) { eq._wired = true; eq.onclick = () => equipTitle(); }
    const clr = $('#title-clear');
    if (clr && !clr._wired) { clr._wired = true; clr.onclick = () => equipTitle(''); }
  }


  window.addEventListener('labcard-change', () => renderAccountLabcard());
  window.addEventListener('llt-change', () => renderAccountLabcard());
  setQuote();
  setFact();
  loadMe();
})();
