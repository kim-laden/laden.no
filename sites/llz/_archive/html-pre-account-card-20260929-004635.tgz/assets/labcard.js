/* Laden Labs ID card — hover the nav username / Login button */
(function () {
  const API = '/labs/api';
  const TOKEN_KEY = 'laden_v12_token';
  const NICK_KEY = 'laden_guest_nick';
  const CACHE_KEY = 'laden_labcard_v1';
  const SKINS = [
    'default',
    'neon-grid',
    'purple-haze',
    'ice-ops',
    'ember',
    'matrix',
    'gold-op',
    'void',
  ];
  const SKIN_META = {
    default: { label: 'Default', blurb: 'Classic ops green' },
    'neon-grid': { label: 'Neon Grid', blurb: 'Cyan grid glow' },
    'purple-haze': { label: 'Purple Haze', blurb: 'Violet haze' },
    'ice-ops': { label: 'Ice Ops', blurb: 'Frost blue' },
    ember: { label: 'Ember', blurb: 'Hot amber' },
    matrix: { label: 'Matrix', blurb: 'Terminal rain' },
    'gold-op': { label: 'Gold Op', blurb: 'VIP gold' },
    void: { label: 'Void', blurb: 'Deep space' },
  };
  const COST = 10;

  function token() {
    try { return localStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; }
  }
  function jwtUser() {
    const t = token();
    if (!t) return null;
    try {
      const p = JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      if (p.exp && Date.now() / 1000 > p.exp) return null;
      const usr = p.usr || p.username || p.sub;
      return usr ? { username: usr } : null;
    } catch { return null; }
  }
  function guestNick() {
    try { return (sessionStorage.getItem(NICK_KEY) || '').trim(); } catch { return ''; }
  }
  function lltBal() {
    try {
      if (window.LLT && typeof window.LLT.balance === 'function') return window.LLT.balance();
    } catch {}
    return 10;
  }
  function normalizeSkin(s) {
    s = String(s || 'default').trim();
    return SKINS.indexOf(s) >= 0 ? s : 'default';
  }
  function initials(name, nick) {
    const s = (name || nick || '?').trim();
    const parts = s.split(/\s+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return s.slice(0, 2).toUpperCase();
  }
  function hueFrom(str) {
    let h = 0;
    for (let i = 0; i < (str || '').length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return h % 360;
  }
  function avatarDataUri(name, nick) {
    const ini = initials(name, nick);
    const h = hueFrom(nick || name || 'guest');
    const svg =
      '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="hsl(' + h + ',70%,45%)"/>' +
      '<stop offset="100%" stop-color="hsl(' + ((h + 40) % 360) + ',80%,35%)"/>' +
      '</linearGradient></defs>' +
      '<rect width="96" height="96" rx="18" fill="url(#g)"/>' +
      '<text x="48" y="54" text-anchor="middle" font-family="Orbitron,sans-serif" font-size="28" font-weight="700" fill="#03140c">' +
      ini.replace(/[<>&]/g, '') +
      '</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  let profile = null; // { username, display_name, llt, xp, role, labcard_skin }
  let mountedCard = null;

  function clearCache() {
    try { sessionStorage.removeItem(CACHE_KEY); } catch {}
  }

  async function fetchProfile(force) {
    const ju = jwtUser();
    if (!ju) {
      profile = null;
      return null;
    }
    if (!force) {
      try {
        const cached = JSON.parse(sessionStorage.getItem(CACHE_KEY) || 'null');
        if (cached && cached.username === ju.username && Date.now() - (cached._ts || 0) < 60000) {
          profile = cached;
          return profile;
        }
      } catch {}
    }
    try {
      const res = await fetch(API + '/me', { headers: { Authorization: 'Bearer ' + token() } });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { profile = null; return null; }
      const u = data.user || data;
      profile = {
        username: u.username || ju.username,
        display_name: u.display_name || u.username || ju.username,
        llt: u.llt != null ? u.llt : lltBal(),
        xp: u.xp || 0,
        role: u.role || 'member',
        title: u.title || '',
        title_label: u.title_label || '',
        lab_id: u.lab_id || (u.id != null ? ('969-' + String(u.id).padStart(3, '0')) : ''),
        id: u.id || null,
        labcard_skin: normalizeSkin(u.labcard_skin),
        avatar_id: (window.LadenAvatars && window.LadenAvatars.normalize)
          ? window.LadenAvatars.normalize(u.avatar_id || u.avatar || '')
          : String(u.avatar_id || u.avatar || '').trim(),
        _ts: Date.now(),
      };
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(profile)); } catch {}
      return profile;
    } catch {
      profile = {
        username: ju.username,
        display_name: ju.username,
        llt: lltBal(),
        xp: 0,
        role: 'member',
        title: '',
        title_label: '',
        lab_id: '',
        id: null,
        labcard_skin: 'default',
        avatar_id: '',
        _ts: Date.now(),
      };
      return profile;
    }
  }

  function injectCss() {
    try {
      if (window.LadenAvatars && window.LadenAvatars.ensureCss) window.LadenAvatars.ensureCss();
    } catch {}
    if (document.getElementById('labcard-css')) return;
    const s = document.createElement('style');
    s.id = 'labcard-css';
    s.textContent = `
.nav-labcard{position:relative;display:inline-flex;align-items:center}
.nav-labcard > a#nav-account,.nav-labcard > a#nav-account-btn{position:relative;z-index:2}
.labcard{
  position:absolute;top:100%;right:0;width:280px;z-index:80;
  padding:.55rem 0 0;opacity:0;visibility:hidden;transform:translateY(-6px) scale(.98);
  transition:opacity .18s ease,transform .18s ease,visibility .18s;
  pointer-events:none;
  filter:drop-shadow(0 18px 40px rgba(0,0,0,.55));
}
.labcard::before{
  content:"";display:block;height:.55rem;margin-top:-.55rem;
}
.nav-labcard:hover .labcard,.nav-labcard:focus-within .labcard,.labcard:hover,.labcard.is-open{
  opacity:1;visibility:visible;transform:translateY(0) scale(1);pointer-events:auto;
}
.labcard-inner{
  position:relative;overflow:hidden;border-radius:16px;
  border:1px solid rgba(0,255,157,.4);
  background:
    linear-gradient(145deg,rgba(6,18,14,.97),rgba(4,12,20,.98) 55%,rgba(10,8,24,.98)),
    radial-gradient(circle at 100% 0%,rgba(0,255,157,.18),transparent 45%);
  padding:1rem 1rem 1.05rem;
  --lc-accent:#00ff9d; --lc-accent2:#00e5ff; --lc-glow:rgba(0,255,157,.45);
}
.labcard-inner::before{
  content:"";position:absolute;inset:0;background:
    repeating-linear-gradient(-45deg,transparent,transparent 8px,rgba(0,255,157,.03) 8px,rgba(0,255,157,.03) 9px);
  pointer-events:none;
}
.labcard-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;position:relative}
.labcard-badge{
  font-family:JetBrains Mono,monospace;font-size:.62rem;letter-spacing:.12em;font-weight:700;
  padding:.2rem .45rem;border-radius:999px;background:linear-gradient(90deg,var(--lc-accent),var(--lc-accent2));color:#03140c;
}
.labcard-id{font-family:JetBrains Mono,monospace;font-size:.65rem;color:rgba(230,241,255,.55)}
.labcard-body{display:flex;gap:.85rem;align-items:center;position:relative}
.labcard-avatar{
  width:64px;height:64px;border-radius:16px;object-fit:cover;flex-shrink:0;
  border:2px solid var(--lc-glow);box-shadow:0 0 0 3px rgba(0,0,0,.35),0 0 18px color-mix(in srgb, var(--lc-accent) 35%, transparent);
  background:#0a1612;
}
.labcard-meta{min-width:0;flex:1}
.labcard-name{
  font-family:Orbitron,sans-serif;font-size:.95rem;font-weight:700;color:#e6f1ff;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:0 0 .15rem;
}
.labcard-nick{font-family:JetBrains Mono,monospace;font-size:.78rem;color:var(--lc-accent2);margin:0 0 .45rem}
.labcard-row{display:flex;flex-wrap:wrap;gap:.4rem;align-items:center}
.labcard-pill{
  font-size:.72rem;font-family:JetBrains Mono,monospace;padding:.25rem .5rem;border-radius:999px;
  border:1px solid color-mix(in srgb, var(--lc-accent) 40%, transparent);background:color-mix(in srgb, var(--lc-accent) 10%, transparent);color:#e6f1ff;
}
.labcard-pill b{color:var(--lc-accent)}
.labcard-foot{
  margin-top:.85rem;padding-top:.65rem;border-top:1px solid color-mix(in srgb, var(--lc-accent) 18%, transparent);
  font-size:.68rem;color:rgba(230,241,255,.45);font-family:JetBrains Mono,monospace;position:relative;
}
.labcard-guest .labcard-badge{background:linear-gradient(90deg,#a78bfa,#00e5ff)}

.labcard-foot-row{display:flex;justify-content:space-between;align-items:center;gap:.5rem;flex-wrap:wrap}
.labcard-role{font-size:.65rem;color:rgba(230,241,255,.4);letter-spacing:.04em}
.labcard-logout{
  font-family:JetBrains Mono,monospace;font-size:.68rem;padding:.28rem .55rem;border-radius:8px;cursor:pointer;
  border:1px solid rgba(255,107,122,.45);background:rgba(255,107,122,.1);color:#ff8a8a;
}
.labcard-logout:hover{background:rgba(255,107,122,.22);border-color:rgba(255,107,122,.7)}
.labcard-title-pill{
  font-size:.68rem;font-family:JetBrains Mono,monospace;padding:.2rem .45rem;border-radius:999px;
  border:1px solid color-mix(in srgb, var(--lc-accent2) 45%, transparent);
  background:color-mix(in srgb, var(--lc-accent2) 12%, transparent);color:var(--lc-accent2);
  letter-spacing:.06em;text-transform:uppercase;
}


/* --- skins --- */
.labcard[data-skin="neon-grid"] .labcard-inner{
  --lc-accent:#00e5ff; --lc-accent2:#7cfcff; --lc-glow:rgba(0,229,255,.55);
  border-color:rgba(0,229,255,.55);
  background:
    linear-gradient(145deg,rgba(2,12,24,.98),rgba(4,8,20,.98) 55%,rgba(0,20,32,.98)),
    radial-gradient(circle at 0% 100%,rgba(0,229,255,.22),transparent 50%);
  box-shadow:inset 0 0 0 1px rgba(0,229,255,.12),0 0 28px rgba(0,229,255,.18);
}
.labcard[data-skin="neon-grid"] .labcard-inner::before{
  background:
    linear-gradient(rgba(0,229,255,.07) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,229,255,.07) 1px,transparent 1px);
  background-size:14px 14px;
}

.labcard[data-skin="purple-haze"] .labcard-inner{
  --lc-accent:#c084fc; --lc-accent2:#e879f9; --lc-glow:rgba(192,132,252,.55);
  border-color:rgba(192,132,252,.5);
  background:
    linear-gradient(145deg,rgba(18,8,28,.98),rgba(10,6,22,.98) 50%,rgba(20,10,36,.98)),
    radial-gradient(circle at 90% 10%,rgba(232,121,249,.28),transparent 45%);
}
.labcard[data-skin="purple-haze"] .labcard-inner::before{
  background:radial-gradient(ellipse at 30% 120%,rgba(167,139,250,.2),transparent 55%),
    repeating-linear-gradient(120deg,transparent,transparent 10px,rgba(192,132,252,.04) 10px,rgba(192,132,252,.04) 11px);
}

.labcard[data-skin="ice-ops"] .labcard-inner{
  --lc-accent:#93c5fd; --lc-accent2:#e0f2fe; --lc-glow:rgba(147,197,253,.55);
  border-color:rgba(147,197,253,.55);
  background:
    linear-gradient(160deg,rgba(8,16,28,.98),rgba(12,22,36,.98) 60%,rgba(6,14,26,.98)),
    radial-gradient(circle at 80% 0%,rgba(186,230,253,.25),transparent 40%);
}
.labcard[data-skin="ice-ops"] .labcard-inner::before{
  background:repeating-linear-gradient(0deg,transparent,transparent 6px,rgba(186,230,253,.05) 6px,rgba(186,230,253,.05) 7px);
}

.labcard[data-skin="ember"] .labcard-inner{
  --lc-accent:#fb923c; --lc-accent2:#fbbf24; --lc-glow:rgba(251,146,60,.55);
  border-color:rgba(251,146,60,.5);
  background:
    linear-gradient(145deg,rgba(28,10,6,.98),rgba(18,8,6,.98) 55%,rgba(32,12,8,.98)),
    radial-gradient(circle at 100% 100%,rgba(239,68,68,.28),transparent 45%);
}
.labcard[data-skin="ember"] .labcard-inner::before{
  background:radial-gradient(circle at 20% 0%,rgba(251,191,36,.15),transparent 40%),
    repeating-linear-gradient(45deg,transparent,transparent 9px,rgba(251,146,60,.04) 9px,rgba(251,146,60,.04) 10px);
}

.labcard[data-skin="matrix"] .labcard-inner{
  --lc-accent:#22c55e; --lc-accent2:#86efac; --lc-glow:rgba(34,197,94,.55);
  border-color:rgba(34,197,94,.5);
  background:linear-gradient(180deg,#020805,#041008 40%,#030a06);
  font-variant-numeric:tabular-nums;
}
.labcard[data-skin="matrix"] .labcard-inner::before{
  background:
    repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(34,197,94,.06) 3px,rgba(34,197,94,.06) 4px),
    repeating-linear-gradient(90deg,transparent,transparent 11px,rgba(34,197,94,.04) 11px,rgba(34,197,94,.04) 12px);
}
.labcard[data-skin="matrix"] .labcard-name,
.labcard[data-skin="matrix"] .labcard-nick{color:#86efac;text-shadow:0 0 8px rgba(34,197,94,.45)}

.labcard[data-skin="gold-op"] .labcard-inner{
  --lc-accent:#fbbf24; --lc-accent2:#fde68a; --lc-glow:rgba(251,191,36,.55);
  border-color:rgba(251,191,36,.55);
  background:
    linear-gradient(145deg,rgba(24,18,6,.98),rgba(16,12,4,.98) 55%,rgba(28,20,8,.98)),
    radial-gradient(circle at 50% 0%,rgba(251,191,36,.22),transparent 50%);
  box-shadow:inset 0 0 24px rgba(251,191,36,.08),0 0 20px rgba(251,191,36,.12);
}
.labcard[data-skin="gold-op"] .labcard-inner::before{
  background:repeating-linear-gradient(-30deg,transparent,transparent 12px,rgba(251,191,36,.05) 12px,rgba(251,191,36,.05) 13px);
}
.labcard[data-skin="gold-op"] .labcard-badge{color:#1a1200}

.labcard[data-skin="void"] .labcard-inner{
  --lc-accent:#a78bfa; --lc-accent2:#67e8f9; --lc-glow:rgba(167,139,250,.5);
  border-color:rgba(167,139,250,.4);
  background:
    radial-gradient(circle at 20% 30%,rgba(99,102,241,.25),transparent 35%),
    radial-gradient(circle at 80% 70%,rgba(34,211,238,.18),transparent 40%),
    linear-gradient(160deg,#05050a,#0a0614 50%,#04040c);
}
.labcard[data-skin="void"] .labcard-inner::before{
  background:radial-gradient(1px 1px at 20% 30%,rgba(255,255,255,.5),transparent),
    radial-gradient(1px 1px at 70% 60%,rgba(255,255,255,.35),transparent),
    radial-gradient(1.5px 1.5px at 40% 80%,rgba(255,255,255,.4),transparent),
    radial-gradient(1px 1px at 85% 20%,rgba(255,255,255,.3),transparent);
}

@media (max-width:640px){
  .labcard{right:auto;left:50%;transform:translate(-50%,-6px) scale(.98);width:min(280px,92vw)}
  .nav-labcard:hover .labcard,.nav-labcard:focus-within .labcard,.labcard.is-open{transform:translate(-50%,0) scale(1)}
}

/* Account picker previews */
.labcard-skin-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:.75rem;margin:1rem 0}
.labcard-skin-opt{
  cursor:pointer;border-radius:14px;padding:.65rem;text-align:left;
  border:1px solid rgba(230,241,255,.12);background:rgba(0,0,0,.25);
  transition:border-color .15s,box-shadow .15s,transform .15s;
}
.labcard-skin-opt:hover{transform:translateY(-2px);border-color:rgba(0,255,157,.35)}
.labcard-skin-opt.is-selected{border-color:rgba(0,255,157,.65);box-shadow:0 0 0 1px rgba(0,255,157,.25),0 8px 24px rgba(0,0,0,.35)}
.labcard-skin-preview{
  height:64px;border-radius:10px;margin-bottom:.5rem;border:1px solid rgba(255,255,255,.1);
  position:relative;overflow:hidden;
}
.labcard-skin-preview::after{
  content:"";position:absolute;left:.55rem;top:.55rem;width:2.2rem;height:.55rem;border-radius:999px;
  background:linear-gradient(90deg,var(--pv-a,#00ff9d),var(--pv-b,#00e5ff));
}
.labcard-skin-opt strong{display:block;font-size:.85rem;color:#e6f1ff}
.labcard-skin-opt span{font-size:.72rem;color:rgba(230,241,255,.5);font-family:JetBrains Mono,monospace}
.labcard-skin-preview.pv-default{--pv-a:#00ff9d;--pv-b:#00e5ff;background:linear-gradient(145deg,#06120e,#0a0818)}
.labcard-skin-preview.pv-neon-grid{--pv-a:#00e5ff;--pv-b:#7cfcff;background:linear-gradient(145deg,#020c18,#001420);
  background-image:linear-gradient(rgba(0,229,255,.12) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,255,.12) 1px,transparent 1px),linear-gradient(145deg,#020c18,#001420);background-size:10px 10px,10px 10px,auto}
.labcard-skin-preview.pv-purple-haze{--pv-a:#c084fc;--pv-b:#e879f9;background:linear-gradient(145deg,#12081c,#140a24)}
.labcard-skin-preview.pv-ice-ops{--pv-a:#93c5fd;--pv-b:#e0f2fe;background:linear-gradient(160deg,#08101c,#0c1624)}
.labcard-skin-preview.pv-ember{--pv-a:#fb923c;--pv-b:#fbbf24;background:linear-gradient(145deg,#1c0a06,#200c08)}
.labcard-skin-preview.pv-matrix{--pv-a:#22c55e;--pv-b:#86efac;background:linear-gradient(180deg,#020805,#041008)}
.labcard-skin-preview.pv-gold-op{--pv-a:#fbbf24;--pv-b:#fde68a;background:linear-gradient(145deg,#181206,#1c1408)}
.labcard-skin-preview.pv-void{--pv-a:#a78bfa;--pv-b:#67e8f9;background:radial-gradient(circle at 30% 40%,#1e1b4b,#05050a 70%)}
.labcard-skin-actions{display:flex;flex-wrap:wrap;gap:.6rem;align-items:center;margin-top:.35rem}
.labcard-skin-msg{font-size:.82rem;min-height:1.2em;margin:.4rem 0 0}
`;
    document.head.appendChild(s);
  }

  function renderCard(el, data) {
    const member = !!data.member;
    const name = data.name || 'Operator';
    const nick = data.nick || 'guest';
    const bal = data.llt != null ? data.llt : lltBal();
    const xp = data.xp;
    const role = data.role || (member ? 'member' : 'guest');
    const titleLabel = (data.title_label || '').trim();
    const titleId = (data.title || '').trim();
    const labId = (data.lab_id || '').trim();
    const skin = member ? normalizeSkin(data.skin) : 'default';
    const avatarId = member ? String(data.avatar || data.avatar_id || '').trim() : '';
    let avHtml = '';
    if (avatarId && window.LadenAvatars && window.LadenAvatars.html) {
      try { window.LadenAvatars.ensureCss && window.LadenAvatars.ensureCss(); } catch {}
      avHtml = '<div class="labcard-avatar-slot">' + window.LadenAvatars.html(avatarId) + '</div>';
    }
    if (!avHtml) {
      const av = avatarDataUri(name, nick);
      avHtml = '<div class="labcard-avatar-slot has-initials"><img class="labcard-avatar" alt="" width="64" height="64" src="' + av + '"></div>';
    }
    const idText = member
      ? (labId || '969-???')
      : 'GUEST';
    const titleHtml = (member && (titleLabel || titleId))
      ? '<span class="labcard-title-pill">' + String(titleLabel || titleId).replace(/</g, '&lt;') + '</span>'
      : '';
    const roleSecondary = member
      ? '<span class="labcard-role">' + (titleHtml ? ('role · ' + role) : role.toUpperCase()) + '</span>'
      : '';
    el.className = 'labcard' + (member ? '' : ' labcard-guest');
    el.setAttribute('data-skin', skin);
    el.innerHTML =
      '<div class="labcard-inner">' +
      '<div class="labcard-top">' +
      '<span class="labcard-badge">' + (member ? 'LAB ID' : 'GUEST PASS') + '</span>' +
      '<span class="labcard-id">' + idText.replace(/</g, '&lt;') + '</span>' +
      '</div>' +
      '<div class="labcard-body">' +
      avHtml +
      '<div class="labcard-meta">' +
      '<p class="labcard-name" title="' + name.replace(/"/g, '&quot;') + '">' + name.replace(/</g, '&lt;') + '</p>' +
      '<p class="labcard-nick">@' + String(nick).replace(/</g, '&lt;') + '</p>' +
      '<div class="labcard-row">' +
      titleHtml +
      '<span class="labcard-pill">LLT <b data-llt-balance>' + bal + '</b></span>' +
      (xp != null ? '<span class="labcard-pill">XP <b data-llt-xp>' + xp + '</b></span>' : '') +
      '</div></div></div>' +
      '<div class="labcard-foot"><div class="labcard-foot-row">' +
      '<span>' + (member
        ? (roleSecondary + (roleSecondary ? ' · ' : '') + 'skin <b style="color:var(--lc-accent)">' + skin + '</b>')
        : 'Session only · <a href="/account/" style="color:var(--cyan,#00e5ff)">create account</a>') +
      '</span>' +
      (member ? '<button type="button" class="labcard-logout" data-labcard-logout>Log out</button>' : '') +
      '</div></div></div>';
    const lo = el.querySelector('[data-labcard-logout]');
    if (lo) lo.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); doLogout(); });
  }

  function paintFromState(card) {
    if (!card) return;
    const ju = jwtUser();
    if (ju && profile) {
      renderCard(card, {
        member: true,
        name: profile.display_name,
        nick: profile.username,
        llt: (window.LLT && window.LLT.balance) ? window.LLT.balance() : profile.llt,
        xp: (window.LLT && window.LLT.get && window.LLT.get().xp != null) ? window.LLT.get().xp : profile.xp,
        role: profile.role,
        title: profile.title || '',
        title_label: profile.title_label || '',
        lab_id: profile.lab_id || '',
        skin: profile.labcard_skin,
        avatar_id: profile.avatar_id || '',
        avatar: profile.avatar_id || '',
      });
      return;
    }
    if (ju) {
      renderCard(card, {
        member: true,
        name: ju.username,
        nick: ju.username,
        llt: lltBal(),
        xp: null,
        role: 'member',
        skin: 'default',
      });
      return;
    }
    const g = guestNick();
    renderCard(card, {
      member: false,
      name: g || 'Guest hunter',
      nick: g || 'guest',
      llt: lltBal(),
      xp: null,
      role: 'guest',
      skin: 'default',
    });
  }

  async function refresh(force) {
    await fetchProfile(!!force);
    if (mountedCard) paintFromState(mountedCard);
    try { window.dispatchEvent(new CustomEvent('labcard-change', { detail: { skin: profile && profile.labcard_skin } })); } catch {}
    return profile;
  }

  function setLocalSkin(skin) {
    skin = normalizeSkin(skin);
    if (profile) {
      profile.labcard_skin = skin;
      profile._ts = Date.now();
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(profile)); } catch {}
    }
    if (mountedCard) paintFromState(mountedCard);
  }

  function setLocalAvatar(avatarId) {
    avatarId = (window.LadenAvatars && window.LadenAvatars.normalize)
      ? window.LadenAvatars.normalize(avatarId)
      : String(avatarId || '').trim();
    if (profile) {
      profile.avatar_id = avatarId;
      profile._ts = Date.now();
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(profile)); } catch {}
    }
    if (mountedCard) paintFromState(mountedCard);
  }

  async function mount() {
    const btn = document.getElementById('nav-account') || document.getElementById('nav-account-btn');
    if (!btn || btn.closest('.nav-labcard')) return;
    injectCss();
    const wrap = document.createElement('div');
    wrap.className = 'nav-labcard';
    btn.parentNode.insertBefore(wrap, btn);
    wrap.appendChild(btn);
    const card = document.createElement('div');
    card.className = 'labcard';
    card.setAttribute('role', 'tooltip');
    card.setAttribute('data-skin', 'default');
    wrap.appendChild(card);
    mountedCard = card;
    paintFromState(card);
    await fetchProfile();
    paintFromState(card);
    window.addEventListener('llt-change', () => paintFromState(card));
    window.addEventListener('laden-nick', () => paintFromState(card));
  }


  function doLogout() {
    try { localStorage.removeItem(TOKEN_KEY); } catch {}
    clearCache();
    profile = null;
    try {
      document.querySelectorAll('#nav-account,#nav-account-btn').forEach(function (el) { el.textContent = 'Login'; });
    } catch {}
    if (mountedCard) {
      try { mountedCard.classList.remove('is-open'); } catch {}
      paintFromState(mountedCard);
    }
    try { window.dispatchEvent(new CustomEvent('laden-logout')); } catch {}
    var path = location.pathname || '';
    if (path.indexOf('/account') === 0) {
      location.reload();
    } else {
      location.href = '/account/';
    }
  }

  function setLocalTitle(title, titleLabel) {
    if (profile) {
      profile.title = title || '';
      profile.title_label = titleLabel || '';
      profile._ts = Date.now();
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(profile)); } catch {}
    }
    if (mountedCard) paintFromState(mountedCard);
  }

  window.LabCard = {
    SKINS,
    SKIN_META,
    COST,
    normalizeSkin,
    clearCache,
    refresh,
    setLocalSkin,
    setLocalAvatar,
    setLocalTitle,
    logout: doLogout,
    getSkin() { return profile ? normalizeSkin(profile.labcard_skin) : 'default'; },
    getAvatar() { return profile ? (profile.avatar_id || '') : ''; },
    getTitle() { return profile ? (profile.title || '') : ''; },
    getLabId() { return profile ? (profile.lab_id || '') : ''; },
    getProfile() { return profile; },
    renderInto(el, data) {
      if (!el) return;
      injectCss();
      renderCard(el, data || {
        member: true,
        name: profile && profile.display_name,
        nick: profile && profile.username,
        lab_id: profile && profile.lab_id,
        title: profile && profile.title,
        title_label: profile && profile.title_label,
        llt: profile && profile.llt,
        xp: profile && profile.xp,
        role: profile && profile.role,
        skin: profile && profile.labcard_skin,
        avatar_id: profile && profile.avatar_id,
        avatar: profile && profile.avatar_id,
      });
    },
    injectCss,
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
